# GGIF Previews

<script>
(async () => {
  const STATIC_PATH = "/static/";

  // Get directory listing
  const html = await fetch(STATIC_PATH).then(r => r.text());

  // Extract links from directory listing
  const doc = new DOMParser().parseFromString(html, "text/html");

  const files = [...doc.querySelectorAll("a")]
    .map(a => a.getAttribute("href"))
    .filter(href =>
      href &&
      href !== "../" &&
      !href.endsWith("/")
    )
    .map(href => new URL(href, location.origin + STATIC_PATH).pathname);

  // Gallery
  const gallery = document.createElement("div");

  Object.assign(gallery.style, {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
    gap: "20px",
    padding: "30px 15%",
    boxSizing: "border-box",
    width: "100%"
  });

  const videoExtensions = [
    "mp4", "webm", "ogg", "mov", "m4v"
  ];

  for (const file of files) {
    const filename = decodeURIComponent(file.split("/").pop());
    const ext = filename.split(".").pop().toLowerCase();

    const item = document.createElement("figure");

    Object.assign(item.style, {
      margin: "0",
      minWidth: "0"
    });

    let media;

    if (videoExtensions.includes(ext)) {
      media = document.createElement("video");
      media.controls = true;
      media.preload = "metadata";
    } else {
      media = document.createElement("img");
      media.loading = "lazy";
    }

    media.src = file;

    Object.assign(media.style, {
      width: "100%",
      height: "auto",
      display: "block",
      objectFit: "contain"
    });

    const caption = document.createElement("figcaption");
    caption.style.marginTop = "6px";
    caption.style.textAlign = "center";
    caption.style.wordBreak = "break-all";

    const link = document.createElement("a");
    link.href = file;
    link.textContent = filename;
    link.target = "_blank";
    link.rel = "noopener";

    caption.appendChild(link);
    item.append(media, caption);
    gallery.appendChild(item);
  }

  document.body.appendChild(gallery);
})();
</script>
